<div class="footer">
                    
                    <div>
                        <strong>Copyright</strong> Cyphertext Solutions Ltd. &copy; 2015-2016
                    </div>
                </div>