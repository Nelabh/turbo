
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>TURBO | {{$action}}</title>

    <link href = "{{URL::asset('css/bootstrap.min.css')}}" rel="stylesheet">
    <link href = "{{URL::asset('font-awesome/css/font-awesome.css')}}" rel="stylesheet">

    <!-- Toastr style -->
    <link href = "{{URL::asset('css/plugins/toastr/toastr.min.css')}}" rel="stylesheet">

    <!-- Gritter -->
    <link href = "{{URL::asset('js/plugins/gritter/jquery.gritter.css')}}" rel="stylesheet">

    <link href = "{{URL::asset('css/animate.css')}}" rel="stylesheet">
    <link href = "{{URL::asset('css/style.css')}}" rel="stylesheet">

